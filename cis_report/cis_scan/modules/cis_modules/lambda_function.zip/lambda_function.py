import json
import boto3
import os
from datetime import datetime

inspector = boto3.client("inspector2")
s3 = boto3.client("s3")

BUCKET_NAME = os.environ["BUCKET_NAME"]

def lambda_handler(event, context):
    scans = inspector.list_cis_scans(maxResults=1)

    if "cisScans" not in scans or len(scans["cisScans"]) == 0:
        return {"message": "No CIS scans found"}

    scan_arn = scans["cisScans"][0]["scanArn"]

    findings = []
    paginator = inspector.get_paginator("list_findings")

    for page in paginator.paginate(
        filterCriteria={
            "inspectorScanArn": [
                {"comparison": "EQUALS", "value": scan_arn}
            ]
        }
    ):
        findings.extend(page.get("findings", []))

    file_name = f"cis-findings-{datetime.utcnow().isoformat()}.json"

    s3.put_object(
        Bucket=BUCKET_NAME,
        Key=file_name,
        Body=json.dumps(findings, indent=2),
        ContentType="application/json"
    )

    return {
        "status": "SUCCESS",
        "findings_count": len(findings),
        "s3_object": file_name
    }
